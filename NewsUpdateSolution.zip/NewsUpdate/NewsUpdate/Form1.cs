﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace NewsUpdate
{
    public partial class Form1 : Form
    {
        private string newsFilePath = @"L:\Testing\Matrix\Matrix Dashboard\New Development\news.yml";
        private string exePath = @"L:\Testing\Matrix\Matrix Dashboard\New Development\createBookmarks.exe";
        public Form1()
        { 
            InitializeComponent();

            comboBoxExprDate.Items.Add(DateTime.Now.AddDays(1));
            comboBoxExprDate.Items.Add(DateTime.Now.AddDays(3));
            comboBoxExprDate.Items.Add(DateTime.Now.AddDays(7));
            comboBoxExprDate.Items.Add(DateTime.Now.AddDays(30));
            comboBoxExprDate.Items.Add(DateTime.Now.AddDays(365));

            comboBoxExprDate.SelectedIndex = 0;
            ButtonUpdate.Enabled = false;

            NewsTextBox.Enabled = false;

            ClearExpiredLines();
            //run createBookmarks.
            ExecuteCreateBookMark(exePath);

            NewsTextBox.Enabled = true;

            string ymlFile = File.ReadAllText(newsFilePath);
            NewsTextBox.Text = ymlFile;
            NewsTextBox.Select(0, 0);
            NewsTextBox.SelectionStart = NewsTextBox.Text.Length;
            NewsTextBox.SelectionLength = 0;
        }

        private void ButtonUpdate_Click(object sender, EventArgs e)
        {
            if(NewsTextBox.Text == string.Empty)
            {
                MessageBox.Show("Please add a news before pressing update button!");
                return;
            }
            AddNews();
            NewsTextBox.Clear();
            NewsTextBox.Enabled = false;
            //run createBookmarks.
            ExecuteCreateBookMark(exePath);
            MessageBox.Show("Update completed!");
            ButtonUpdate.Enabled = false;

            string ymlFile = File.ReadAllText(newsFilePath);
            NewsTextBox.Text = ymlFile;
            Thread.Sleep(5000);
            NewsTextBox.Enabled = true;
            NewsTextBox.Select(0, 0);
            NewsTextBox.SelectionStart = NewsTextBox.Text.Length;
            NewsTextBox.SelectionLength = 0;
            ButtonUpdate.Enabled = true;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void ClearTextButton_Click(object sender, EventArgs e)
        {
            NewsTextBox.Clear();
        }

        private void comboBoxExprDate_SelectedIndexChanged(object sender, EventArgs e)
        { 

        }
        //Clear all expired lines from yml file.
        public void ClearExpiredLines()
        {
            string line;
            string[] tmp;
            DateTime dt;
            IList<string> lst = new List<string>();
            //Read line by line.  
            System.IO.StreamReader file = new System.IO.StreamReader(newsFilePath);
            while ((line = file.ReadLine()) != null)
            {
                tmp = line.Split(':');
                tmp[1] = tmp[1].Remove(0, 1);
                dt = DateTime.Parse(tmp[1]+":"+tmp[2]);

                System.Console.WriteLine("dt:" + line);
                System.Console.WriteLine("line:" + line);

                if (dt > DateTime.Now)
                {
                    lst.Add(line);
                }
            }
            file.Close();

            System.IO.File.WriteAllText(newsFilePath, string.Empty);
            using (StreamWriter sw = File.AppendText(newsFilePath))
            {
                for(int i = 0; i < lst.Count; i++)
                {
                    sw.WriteLine(lst[i]);
                }
            }
            file.Close();

        }
        //Add new lines from NewsTextBox to yml file.
        public void AddNews()
        {
            string ymlFile = File.ReadAllText(newsFilePath);
            string[] tmp = NewsTextBox.Text.Split('\r');
            Regex rgx = new Regex(@"\d{2}/\d{2}/\d{4}");
            System.IO.File.WriteAllText(newsFilePath, string.Empty);
            using (StreamWriter sw = File.AppendText(newsFilePath))
            {
                for (int i = 0; i < tmp.Length; i++)
                {
                    tmp[i] = tmp[i].Replace("\n","");
                    tmp[i] = tmp[i].Replace("\r","");
                    if(tmp[i] != string.Empty || tmp[i] != "")
                    {
                        if (rgx.Match(tmp[i]).Success)
                        {
                            if (i == tmp.Length - 1)
                            {
                                sw.Write(tmp[i]);
                            }
                            else
                            {
                                sw.Write(tmp[i] + "\r" + "\n");
                            }
                        }
                        else
                        {
                            if (i == tmp.Length - 1)
                            {
                                sw.Write(tmp[i] + ": " + comboBoxExprDate.Text);
                            }
                            else
                            {
                                sw.Write(tmp[i] + ": " + comboBoxExprDate.Text + "\r" + "\n");
                            }
                        }
                    }
                }
            }
        }

        private void NewsTextBox_TextChanged(object sender, EventArgs e)
        {
            if (NewsTextBox.Text != string.Empty)
            {
                ButtonUpdate.Enabled = true;
            }
        }

        public void ExecuteCreateBookMark(string path)
        {
            string fullPath = path;
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = Path.GetFileName(fullPath);
            psi.WorkingDirectory = Path.GetDirectoryName(fullPath);
            psi.Arguments = "";
            Process.Start(psi);
            Thread.Sleep(5000);
        }
    }
}
