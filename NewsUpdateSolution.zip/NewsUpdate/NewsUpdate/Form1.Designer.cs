﻿
namespace NewsUpdate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NewsTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ButtonUpdate = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ClearTextButton = new System.Windows.Forms.Button();
            this.LabelExprDate = new System.Windows.Forms.Label();
            this.comboBoxExprDate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // NewsTextBox
            // 
            this.NewsTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(244)))), ((int)(((byte)(248)))));
            this.NewsTextBox.Location = new System.Drawing.Point(10, 66);
            this.NewsTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.NewsTextBox.Multiline = true;
            this.NewsTextBox.Name = "NewsTextBox";
            this.NewsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.NewsTextBox.Size = new System.Drawing.Size(312, 244);
            this.NewsTextBox.TabIndex = 0;
            this.NewsTextBox.TextChanged += new System.EventHandler(this.NewsTextBox_TextChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(204)))), ((int)(((byte)(220)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(10, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 55);
            this.label1.TabIndex = 1;
            this.label1.Text = "Live News";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ButtonUpdate
            // 
            this.ButtonUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(204)))), ((int)(((byte)(220)))));
            this.ButtonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ButtonUpdate.Location = new System.Drawing.Point(11, 339);
            this.ButtonUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.ButtonUpdate.Name = "ButtonUpdate";
            this.ButtonUpdate.Size = new System.Drawing.Size(97, 68);
            this.ButtonUpdate.TabIndex = 2;
            this.ButtonUpdate.Text = "Update";
            this.ButtonUpdate.UseVisualStyleBackColor = false;
            this.ButtonUpdate.Click += new System.EventHandler(this.ButtonUpdate_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(204)))), ((int)(((byte)(220)))));
            this.ExitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ExitButton.Location = new System.Drawing.Point(222, 339);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(2);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(100, 68);
            this.ExitButton.TabIndex = 3;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ClearTextButton
            // 
            this.ClearTextButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(204)))), ((int)(((byte)(220)))));
            this.ClearTextButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ClearTextButton.Location = new System.Drawing.Point(112, 339);
            this.ClearTextButton.Margin = new System.Windows.Forms.Padding(2);
            this.ClearTextButton.Name = "ClearTextButton";
            this.ClearTextButton.Size = new System.Drawing.Size(106, 68);
            this.ClearTextButton.TabIndex = 4;
            this.ClearTextButton.Text = "Clear Text";
            this.ClearTextButton.UseVisualStyleBackColor = false;
            this.ClearTextButton.Click += new System.EventHandler(this.ClearTextButton_Click);
            // 
            // LabelExprDate
            // 
            this.LabelExprDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(204)))), ((int)(((byte)(220)))));
            this.LabelExprDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.LabelExprDate.Location = new System.Drawing.Point(11, 314);
            this.LabelExprDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LabelExprDate.Name = "LabelExprDate";
            this.LabelExprDate.Size = new System.Drawing.Size(130, 21);
            this.LabelExprDate.TabIndex = 5;
            this.LabelExprDate.Text = "Expiration Date:";
            // 
            // comboBoxExprDate
            // 
            this.comboBoxExprDate.FormattingEnabled = true;
            this.comboBoxExprDate.Location = new System.Drawing.Point(145, 314);
            this.comboBoxExprDate.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxExprDate.Name = "comboBoxExprDate";
            this.comboBoxExprDate.Size = new System.Drawing.Size(177, 21);
            this.comboBoxExprDate.TabIndex = 6;
            this.comboBoxExprDate.SelectedIndexChanged += new System.EventHandler(this.comboBoxExprDate_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(12, 409);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(225, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "@Created by Abramovich Dinor from AT team.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(101)))), ((int)(((byte)(129)))));
            this.ClientSize = new System.Drawing.Size(333, 428);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxExprDate);
            this.Controls.Add(this.LabelExprDate);
            this.Controls.Add(this.ClearTextButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ButtonUpdate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NewsTextBox);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NewsUpdateForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox NewsTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ButtonUpdate;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button ClearTextButton;
        private System.Windows.Forms.Label LabelExprDate;
        private System.Windows.Forms.ComboBox comboBoxExprDate;
        private System.Windows.Forms.Label label2;
    }
}

